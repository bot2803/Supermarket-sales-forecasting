# Supermarket-sales-forecasting
Time series analysis comprises methods for analyzing time series data in order to extract
meaningful statistics and other characteristics of the data. Time series forecasting is the use of a
model to predict future values based on previously observed values.
This project is mainly for predicting the future happenings that can help the owners.
